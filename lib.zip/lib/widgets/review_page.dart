import 'package:flutter/material.dart';

import '../utilities/size_config.dart';
import '../utilities/constants.dart';
import '../widgets/overall_rating.dart';
import '../widgets/review_comment.dart';
import '../widgets/statistics.dart';

class ReviewPage extends StatelessWidget {
  const ReviewPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAFAFA),
        elevation: 0.0,
        title: const Icon(
          Icons.arrow_back_ios_new,
          color: kMyColor,
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            const OverallRating(),
            divider,
            const Statistics(),
            divider,
            Expanded(
              flex: 6,
              child: Container(
                margin: containerMargin,
                padding: containerPadding,
                child: ListView.separated(
                  separatorBuilder: (context, index) => const Divider(),
                  itemCount: 3,
                  itemBuilder: (context, index) {
                    return const ReviewComment();
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
